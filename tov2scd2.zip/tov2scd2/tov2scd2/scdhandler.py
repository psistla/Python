from pyspark.sql import DataFrame
from pyspark.sql.functions import *
#from logging import Logger

def verify_src_columns(source_df, target_df, metadata_cols):
        if_columns_missing = set([cols for cols in target_df.columns if cols not in source_df.columns]) - set(metadata_cols)
        if if_columns_missing:
            raise Exception(f"Columns missing in source DataFrame: {if_columns_missing}")

def apply_hash_and_alias( source_df, target_df, metadata_cols) -> (list([DataFrame, DataFrame])):
        # Extract columns from target DataFrame excluding metadata columns
        old_cols = [x for x in target_df.columns if x not in metadata_cols]

        # Calculate hash expression
        hash_calc_expr = md5(concat_ws("|", *[col(c) for c in old_cols]))

        # Apply hash calculation and alias to source and target DataFrames
        source_df = source_df.withColumn("hash_value", hash_calc_expr).alias("source_df")
        target_df = target_df.withColumn("hash_value", hash_calc_expr).alias("target_df")

        return source_df, target_df


def convert_scd_2( source_df, target_df, join_keys, metadata_cols=None) -> DataFrame:
        if metadata_cols is None:
            metadata_cols = ['tov2_start_date', 'tov2_end_date', 'tov2_active']
        old_cols = [x for x in target_df.columns]
        verify_src_columns(source_df, target_df, metadata_cols)
        # Apply hash calculation and alias
        source_df, target_df = apply_hash_and_alias(source_df, target_df, metadata_cols)

        # Identify new records
        join_cond = [source_df[join_key] == target_df[join_key] for join_key in join_keys]
        new_df = source_df.join(target_df, join_cond, 'left_anti')

        base_df = target_df.join(source_df, join_cond, 'left')

        # Filter unchanged records or same records
        unchanged_filter_expr = " AND ".join([f"source_df.{key} IS NULL" for key in join_keys])
        unchanged_df = base_df.filter(f"({unchanged_filter_expr}) OR "
                                      f"(source_df.hash_value = target_df.hash_value)") \
            .select("target_df.*")

        # identify updated records
        delta_filter_expr = " and ".join([f"source_df.{key} IS NOT NULL" for key in join_keys])
        updated_df = base_df.filter(f"{delta_filter_expr} AND "
                                    f"source_df.hash_value != target_df.hash_value")

        # pick updated records from source_df for new entry
        updated_new_df = updated_df.select("source_df.*")

        # pick updated records from target_df for obsolete entry
        obsolete_df = updated_df.select("target_df.*") \
            .withColumn("tov2_end_date", current_date()) \
            .withColumn("tov2_active", lit(0))

        # union : new & updated records and add scd2 meta-deta
        delta_df = new_df.union(updated_new_df) \
            .withColumn("tov2_start_date", current_date()) \
            .withColumn("tov2_end_date", lit(None)) \
            .withColumn("tov2_active", lit(1))

        # union all datasets : delta_df + obsolete_df + unchanged_df
        result_df = unchanged_df.select(old_cols). \
            unionByName(delta_df.select(old_cols)). \
            unionByName(obsolete_df.select(old_cols))

        return result_df
