from pyspark.sql import DataFrame
from pyspark.sql.functions import *

def verify_src_columns(df_source, df_target, scd2_cols):
        if_columns_missing = set([cols for cols in df_target.columns if cols not in df_source.columns]) - set(scd2_cols)
        if if_columns_missing:
            raise Exception(f"Columns are missing in the df_source : {if_columns_missing}")

def apply_hash_fnc( df_source, df_target_req, scd2_cols) -> (list[DataFrame, DataFrame]):
        # Extract columns from target DataFrame excluding metadata columns
        old_cols = [x for x in df_target_req.columns if x not in scd2_cols]

        # Calculate hash expression
        hash_calc_expr = md5(concat_ws("|", *[col(c) for c in old_cols]))

        # Apply hash calculation and alias to source and target DataFrames
        df_source = df_source.withColumn("hash_value", hash_calc_expr).alias("df_source")
        df_target_req = df_target_req.withColumn("hash_value", hash_calc_expr).alias("df_target_req")

        return df_source, df_target_req


def convert_scd_2( df_source, df_target, join_keys, scd2_cols=None) -> DataFrame:
        if scd2_cols is None:
            scd2_cols = ['eff_start_date', 'eff_end_date', 'scd2_flag']
        old_cols = [x for x in df_target.columns]
        verify_src_columns(df_source, df_target, scd2_cols)

        # bring history df
        df_hist = df_target.filter(col('scd2_flag')==0)

        # select required df_target_req for scd2 operation
        df_target_req = df_target.filter(col('scd2_flag')==1)
        
        # Apply hash calculation and alias
        df_source, df_target_req = apply_hash_fnc(df_source, df_target_req, scd2_cols)

        # Identify new records
        join_cond = [df_source[join_key] == df_target_req[join_key] for join_key in join_keys]
        df_new = df_source.join(df_target_req, join_cond, 'left_anti')

        df_base = df_target_req.join(df_source, join_cond, 'left')

        # Filter unchanged records or same records
        unchanged_filter_expr = " AND ".join([f"df_source.{key} IS NULL" for key in join_keys])
        df_unchanged = df_base.filter(f"({unchanged_filter_expr}) OR "
                                      f"(df_source.hash_value = df_target_req.hash_value)") \
            .select("df_target_req.*")

        # identify updated records
        updated_filter_expr = " AND ".join([f"df_source.{key} IS NOT NULL" for key in join_keys])
        df_updated = df_base.filter(f"{updated_filter_expr} AND "
                                    f"df_source.hash_value != df_target_req.hash_value")

        # get updated records from df_source for new entry
        df_new_updated = df_updated.select("df_source.*")

        # get updated records from df_target_req for obsolete entry
        df_obsolete = df_updated.select("df_target_req.*") \
            .withColumn("eff_end_date", current_date()) \
            .withColumn("scd2_flag", lit(0))

        # union : new & updated records and add scd2 meta-deta
        df_fresh = df_new.union(df_new_updated) \
            .withColumn("eff_start_date", current_date()) \
            .withColumn("eff_end_date", lit(None)) \
            .withColumn("scd2_flag", lit(1))

        # union all datasets : df_fresh + df_obsolete + df_unchanged
        df_result = df_unchanged.select(old_cols). \
            unionByName(df_fresh.select(old_cols)). \
            unionByName(df_obsolete.select(old_cols)). \
            unionByName(df_hist.select(old_cols))
        
        df_result = df_result.dropDuplicates()

        return df_result
