from setuptools import setup 

setup( 
	name='psscd2', 
	version='1.0', 
	description='A python package to handle scd2', 
	author='Prasanth Sistla', 
	author_email='prasanthsistla@live.com', 
	packages=['psscd2'],
	install_requires=[]
) 
